#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QHash>
#include <QStringList>
#include "Node.h"
#include <iostream>


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_okButton_clicked();

    void on_backButton_clicked();

    void on_upButton_clicked();

    void on_downButton_clicked();

private:
    Ui::MainWindow *ui;
    QStringList mainMenu;
    QStringList programsMenu;
    QStringList frequencyMenu;

    Node mainMenuNode;
    Node programsMenuNode;
    Node frequencyMenuNode;

    Node u; //placeholder

    Node* previousMenuNode = nullptr;

    QString selection;
    QHash<QString, Node > data;

};
#endif // MAINWINDOW_H
