#include "mainwindow.h"

#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , mainMenu(QStringList())
    , programsMenu(QStringList())
    , frequencyMenu(QStringList())
    , mainMenuNode(nullptr,&mainMenu)
    , programsMenuNode(&mainMenuNode, &programsMenu)
    , frequencyMenuNode(&mainMenuNode, &frequencyMenu)
    , u()
    , menuData(QHash<QString, Node>())
    , programsData(QHash<QString, QString>())
{

    ui->setupUi(this);

    this->mainMenu.append("Programs");
    this->mainMenu.append("Frequency");

    this->programsMenu.append("Head");
    this->programsMenu.append("Throat");
    this->programsMenu.append("Chest");
    this->programsMenu.append("Eyes");

    this->frequencyMenu.append("100 Hz");
    this->frequencyMenu.append("200 Hz");

    this->menuData.insert("Main",mainMenuNode);
    this->menuData.insert("Programs",programsMenuNode);
    this->menuData.insert("Frequency",frequencyMenuNode);

    this->programsData.insert("Head","Head");

    ui->listWidget->addItems(mainMenu);
    ui->listWidget->setCurrentRow(0);
}

MainWindow::~MainWindow()
{
    //delete mainMenu;
    delete ui;
}




void MainWindow::on_okButton_clicked()
{

    selection = ui->listWidget->currentItem()->text();

    if(this->menuData.contains(selection)){
        u = Node(this->menuData.value(selection));


        ui->listWidget->clear();

        ui->listWidget->addItems(*u.getData());
        ui->listWidget->setCurrentRow(0);

        u = u.getParent();
        previousMenuNode = &u;
    }
    else if(this->programsData.contains(selection)){
        ui->listWidget->setDisabled(true);
        ui->listWidget->setHidden(true);
    }


}


void MainWindow::on_backButton_clicked()
{
    std::cout << "Back Button Pressed";
    if(!ui->listWidget->isEnabled()){
        ui->listWidget->setDisabled(false);
        ui->listWidget->setHidden(false);
    }
    else{

        ui->listWidget->clear();
        ui->listWidget->addItems(*previousMenuNode->getData());
        ui->listWidget->setCurrentRow(0);
    }
}

void MainWindow::on_upButton_clicked()
{
    if(ui->listWidget->currentRow() > 0){
        ui->listWidget->setCurrentRow(ui->listWidget->currentRow() - 1);
    }
    else{
        ui->listWidget->setCurrentRow(ui->listWidget->currentRow());
    }
}

void MainWindow::on_downButton_clicked()
{
    if(ui->listWidget->currentRow() < (ui->listWidget->count()-1)){
        ui->listWidget->setCurrentRow(ui->listWidget->currentRow() + 1);
    }
    else{
        ui->listWidget->setCurrentRow(ui->listWidget->currentRow());
    }
}
