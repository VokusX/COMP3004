#include "mainwindow.h"

#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , mainMenu(QStringList())
    , programsMenu(QStringList())
    , frequencyMenu(QStringList())
    , data(QHash<QString, QStringList>())
{

    ui->setupUi(this);

    this->mainMenu.append("Programs");
    this->mainMenu.append("Frequency");

    this->programsMenu.append("Head");
    this->programsMenu.append("Throat");
    this->programsMenu.append("Chest");
    this->programsMenu.append("Eyes");

    this->frequencyMenu.append("100 Hz");
    this->frequencyMenu.append("200 Hz");

    this->data.insert("Programs",programsMenu);
    this->data.insert("Frequency",frequencyMenu);

    ui->listWidget->addItems(mainMenu);
}

MainWindow::~MainWindow()
{
    //delete mainMenu;
    delete ui;
}




void MainWindow::on_okButton_clicked()
{

    selection = ui->listWidget->currentItem()->text();

    ui->listWidget->clear();

    ui->listWidget->addItems(this->data.value(selection));

}


void MainWindow::on_backButton_clicked()
{

}

void MainWindow::on_upButton_clicked()
{
    if(ui->listWidget->currentRow() >= 0){
        ui->listWidget->setCurrentRow(ui->listWidget->currentRow() - 1);
    }
}

void MainWindow::on_downButton_clicked()
{
    if(ui->listWidget->currentRow() <= (ui->listWidget->count()-1)){
        ui->listWidget->setCurrentRow(ui->listWidget->currentRow() + 1);
    }
}
