#include "MenuScreenState.h"

void MenuScreenState::addItems(QList<MenuOption*> *content){
    for(int i = 0; i < content->size(); i++){
        this->addItem(content->value(i));
    }
}
