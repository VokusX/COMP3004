#ifndef MENUSCREENSTATE_H
#define MENUSCREENSTATE_H
#include <QListWidget>
#include "MenuOption.h"

class MenuScreenState: public QListWidget{
    void addItems(QList<MenuOption*> *content);

};

#endif // MENUSCREENSTATE_H
